import './subReddit.dart';

class user {
  String UserName;
  List<subReddit> joinedSubReddits;
  String profilePic;
  user(this.UserName, this.joinedSubReddits, this.profilePic);
}
